import os
import boto3
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# MinIO Configuration
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY")
MINIO_BUCKET = os.getenv("MINIO_BUCKET")

# Initialize MinIO client
s3_client = boto3.client(
    "s3",
    endpoint_url=MINIO_ENDPOINT,
    aws_access_key_id=MINIO_ACCESS_KEY,
    aws_secret_access_key=MINIO_SECRET_KEY
)

def list_bucket_objects():
    """List all objects in the MinIO bucket."""
    try:
        response = s3_client.list_objects_v2(Bucket=MINIO_BUCKET)
        if "Contents" in response:
            print(f"Objects in bucket '{MINIO_BUCKET}':")
            for obj in response["Contents"]:
                print(f"- {obj['Key']}")
        else:
            print(f"Bucket '{MINIO_BUCKET}' is empty.")
    except Exception as e:
        print(f"Failed to list bucket objects: {e}")

# Run the test
list_bucket_objects()