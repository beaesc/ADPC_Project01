import sys
import os

# Add the parent directory (ADPC_Project1) to the Python path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from database.connection import DatabaseConnection

try:
    conn = DatabaseConnection.get_connection()
    print("Successfully connected to the PostgreSQL database!")
except Exception as e:
    print("Connection failed:", e)
