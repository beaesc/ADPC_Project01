from database.models import SessionLocal

try:
    session = SessionLocal()
    print("Successfully connected to ORM database")
    session.close()
except Exception as e:
    print(f"ORM connection failed: {e}")