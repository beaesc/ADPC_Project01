from sqlalchemy import create_engine, Column, Integer, String, ForeignKey, Text, DateTime, UniqueConstraint
from sqlalchemy.orm import declarative_base, relationship, sessionmaker
import os
from datetime import datetime

Base = declarative_base()

# Author Model (One-to-Many with Packages)
class Author(Base):
    __tablename__ = "authors"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), unique=True, nullable=False)
    email = Column(String(255), unique=True)

    packages = relationship("Package", back_populates="author")

# Repository Model (One-to-Many with Packages)
class Repository(Base):
    __tablename__ = "repositories"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    packages = relationship("Package", back_populates="repository")

# Package Model (Main Entity, Many-to-One with Author & Repository)
class Package(Base):
    __tablename__ = "packages"

    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    version = Column(String(50), nullable=False)
    description = Column(Text)
    author_id = Column(Integer, ForeignKey("authors.id", ondelete="SET NULL"))
    repo_id = Column(Integer, ForeignKey("repositories.id", ondelete="CASCADE"))
    artifact_path = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

    author = relationship("Author", back_populates="packages")
    repository = relationship("Repository", back_populates="packages")
    details = relationship("PackageDetails", uselist=False, back_populates="package")

    __table_args__ = (UniqueConstraint("name", "version", name="unique_package_version"),)

# PackageDetails Model (One-to-One with Package)
class PackageDetails(Base):
    __tablename__ = "package_details"

    package_id = Column(Integer, ForeignKey("packages.id"), primary_key=True)
    release_notes = Column(Text)
    documentation_link = Column(Text)

    package = relationship("Package", back_populates="details")

# Dependency Model (Many-to-Many Self-Referencing Relationship)
class Dependency(Base):
    __tablename__ = "dependencies"

    package_id = Column(Integer, ForeignKey("packages.id", ondelete="CASCADE"), primary_key=True)
    dependency_id = Column(Integer, ForeignKey("packages.id", ondelete="CASCADE"), primary_key=True)

# User Model (Many-to-Many with Repositories via UserRepositoryAccess)
class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True)
    username = Column(String(255), unique=True, nullable=False)
    email = Column(String(255), unique=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)

# User-Repository Access Model (Many-to-Many Relationship)
class UserRepositoryAccess(Base):
    __tablename__ = "user_repository_access"

    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), primary_key=True)
    repo_id = Column(Integer, ForeignKey("repositories.id", ondelete="CASCADE"), primary_key=True)
    access_level = Column(String(50))

# Database Connection
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:password@localhost:5432/postgres")
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Initialize the Database
def init_db():
    Base.metadata.create_all(bind=engine)
