"""Add package tags

Revision ID: ce6a5f4e0942
Revises: 4c21c6eff8c8
Create Date: 2025-02-11 18:28:52.839820

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'ce6a5f4e0942'
down_revision: Union[str, None] = '4c21c6eff8c8'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None

# Add a new column to packages
def upgrade():
    # op.add_column(table_name, column_name)
    op.add_column("packages", sa.Column("tags", sa.String(255)))

def downgrade():
    op.drop_column("packages", "tags")
