"""Final initial migration

Revision ID: c7fcdbccac24
Revises: 
Create Date: 2025-02-11 17:38:37.988315

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "c7fcdbccac24"
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Apply migrations to create database tables"""

    op.create_table(
        "authors",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), unique=True, nullable=False),
        sa.Column("email", sa.String(255), unique=True),
    )

    op.create_table(
        "repositories",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), unique=True, nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "packages",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("name", sa.String(255), nullable=False),
        sa.Column("version", sa.String(50), nullable=False),
        sa.Column("description", sa.Text),
        sa.Column("author_id", sa.Integer, sa.ForeignKey("authors.id", ondelete="SET NULL")),
        sa.Column("repo_id", sa.Integer, sa.ForeignKey("repositories.id", ondelete="CASCADE")),
        sa.Column("artifact_path", sa.Text),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
        sa.UniqueConstraint("name", "version", name="unique_package_version"),
    )

    op.create_table(
        "package_details",
        sa.Column("package_id", sa.Integer, sa.ForeignKey("packages.id"), primary_key=True),
        sa.Column("release_notes", sa.Text),
        sa.Column("documentation_link", sa.Text),
    )

    op.create_table(
        "dependencies",
        sa.Column("package_id", sa.Integer, sa.ForeignKey("packages.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("dependency_id", sa.Integer, sa.ForeignKey("packages.id", ondelete="CASCADE"), primary_key=True),
    )

    op.create_table(
        "users",
        sa.Column("id", sa.Integer, primary_key=True),
        sa.Column("username", sa.String(255), unique=True, nullable=False),
        sa.Column("email", sa.String(255), unique=True, nullable=False),
        sa.Column("created_at", sa.DateTime, server_default=sa.func.now()),
    )

    op.create_table(
        "user_repository_access",
        sa.Column("user_id", sa.Integer, sa.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("repo_id", sa.Integer, sa.ForeignKey("repositories.id", ondelete="CASCADE"), primary_key=True),
        sa.Column("access_level", sa.String(50)),
    )


def downgrade() -> None:
    """Revert the migration by dropping tables"""
    op.drop_table("user_repository_access")
    op.drop_table("users")
    op.drop_table("dependencies")
    op.drop_table("package_details")
    op.drop_table("packages")
    op.drop_table("repositories")
    op.drop_table("authors")
