import re
import os
from abc import ABC, abstractmethod
from database.connection import DatabaseConnection
from database.storage import upload_file

class AbstractRepository(ABC):
    """Abstract repository enforcing implementation of required methods."""
    
    def __init__(self):
        self.conn = DatabaseConnection.get_connection()

    @abstractmethod
    def get_packages_by_repo(self, repo_name):
        pass

    @abstractmethod
    def get_package_info(self, package_name):
        pass

    @abstractmethod
    def find_packages(self, search_query):
        pass

class PackageRepository(AbstractRepository):
    """Concrete implementation of PackageRepository with data validation."""

    def get_packages_by_repo(self, repo_name):
        """Retrieve all packages in a given repository."""
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT name, version FROM packages WHERE repo_id = (SELECT id FROM repositories WHERE name = %s)", (repo_name,))
            return [{"name": row[0], "version": row[1]} for row in cursor.fetchall()]

    def get_package_info(self, package_name):
        """Retrieve package details including name, description, author, and version history."""
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT name, description, author FROM packages WHERE name = %s", (package_name,))
            package = cursor.fetchone()
            if not package:
                return None

            cursor.execute("SELECT version FROM packages WHERE name = %s ORDER BY version DESC", (package_name,))
            versions = [row[0] for row in cursor.fetchall()]

            return {
                "name": package[0],
                "description": package[1],
                "author": package[2],
                "versions": versions
            }
        
    def find_packages(self, search_query):
        """Find packages that match a given search query (case-insensitive)."""
        with self.conn.cursor() as cursor:
            cursor.execute("SELECT name, version FROM packages WHERE name ILIKE %s", (f"%{search_query}%",))
            return [{"name": row[0], "version": row[1]} for row in cursor.fetchall()]

    def is_valid_package_name(self, name):
        """Validate package name (only alphanumeric, underscores, and hyphens)."""
        return bool(re.match(r'^[a-zA-Z0-9_-]+$', name))

    def is_valid_version(self, version):
        """Ensure version follows semantic versioning format (e.g., 1.0.0)."""
        return bool(re.match(r'^\d+\.\d+\.\d+$', version))

    def check_cyclic_dependency(self, package_name):
        """Check for cyclic dependencies using Depth-First Search (DFS)."""
        def dfs(pkg, visited, stack):
            visited.add(pkg)
            stack.add(pkg)

            with self.conn.cursor() as cursor:
                cursor.execute("SELECT dependency_id FROM dependencies WHERE package_id = (SELECT id FROM packages WHERE name = %s)", (pkg,))
                dependencies = [row[0] for row in cursor.fetchall()]

                for dep in dependencies:
                    cursor.execute("SELECT name FROM packages WHERE id = %s", (dep,))
                    dep_name = cursor.fetchone()
                    if dep_name:
                        dep_name = dep_name[0]
                        if dep_name in stack or (dep_name not in visited and dfs(dep_name, visited, stack)):
                            return True

            stack.remove(pkg)
            return False

        visited, stack = set(), set()
        return dfs(package_name, visited, stack)

    def publish_package(self, name, description, version, author, artifact_path, dependencies=[]):
        """Publish a new package and upload the artifact to MinIO."""

        # Check if the artifact exists
        if not os.path.exists(artifact_path):
            print(f"Error: Artifact file '{artifact_path}' not found.")
            return False

        # Upload artifact to MinIO
        artifact_name = f"{name}-{version}.bin"
        artifact_url = upload_file(artifact_path, artifact_name)

        if not artifact_url:
            print("Error: Failed to upload artifact.")
            return False

        # Store the artifact URL in PostgreSQL
        with self.conn.cursor() as cursor:
            # Check if artifact is already in the db
            cursor.execute("SELECT COUNT(*) FROM packages WHERE name = %s AND version = %s", (name, version))
            if cursor.fetchone()[0] > 0:
                print(f"Error: Package '{name}' version '{version}' already exists.")
                return False

            package_id = cursor.fetchone()[0]

            # Insert dependencies if provided
            for dep in dependencies:
                cursor.execute("SELECT id FROM packages WHERE name = %s", (dep,))
                dep_id = cursor.fetchone()
                if dep_id:
                    dep_id = dep_id[0]
                    cursor.execute("INSERT INTO dependencies (package_id, dependency_id) VALUES (%s, %s)", (package_id, dep_id))
                else:
                    print(f"Warning: Dependency '{dep}' does not exist. Skipping.")

        self.conn.commit()
        print(f"Package '{name}' version '{version}' published successfully with artifact at {artifact_url}!")
        return True