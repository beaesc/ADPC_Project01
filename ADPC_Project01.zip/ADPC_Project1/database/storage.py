import os
import boto3
from dotenv import load_dotenv

# Load MinIO credentials from .env
load_dotenv()

# MinIO Configuration
MINIO_ENDPOINT = os.getenv("MINIO_ENDPOINT")
MINIO_ACCESS_KEY = os.getenv("MINIO_ACCESS_KEY")
MINIO_SECRET_KEY = os.getenv("MINIO_SECRET_KEY")
MINIO_BUCKET = os.getenv("MINIO_BUCKET")

# Initialize MinIO client
s3_client = boto3.client(
    "s3",
    endpoint_url=MINIO_ENDPOINT,  # MinIO's API endpoint
    aws_access_key_id=MINIO_ACCESS_KEY,
    aws_secret_access_key=MINIO_SECRET_KEY
)

def upload_file(file_path, file_name):
    """Uploads a package artifact to MinIO."""
    try:
        s3_client.upload_file(file_path, MINIO_BUCKET, file_name)
        print(f"Uploaded {file_name} to MinIO!")
        return f"{MINIO_ENDPOINT}/{MINIO_BUCKET}/{file_name}"  # Return file URL
    except Exception as e:
        print(f"Upload failed: {e}")
        return None

def get_file(file_name):
    """Gets a download URL for a package artifact."""
    try:
        url = s3_client.generate_presigned_url(
            'get_object',
            Params={'Bucket': MINIO_BUCKET, 'Key': file_name},
            ExpiresIn=7200  # URL expires in 1 hour
        )
        return url
    except Exception as e:
        print(f"Failed to generate download link: {e}")
        return None

def delete_file(file_name):
    """Deletes an artifact from MinIO."""
    try:
        s3_client.delete_object(Bucket=MINIO_BUCKET, Key=file_name)
        print(f"Deleted {file_name} from MinIO.")
    except Exception as e:
        print(f"Delete failed: {e}")
