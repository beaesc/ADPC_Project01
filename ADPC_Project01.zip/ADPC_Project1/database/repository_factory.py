from database.repository import PackageRepository

class RepositoryFactory:
    """Factory class to create repository instances."""
    
    @staticmethod
    def get_repository(repo_type):
        if repo_type == "package":
            return PackageRepository()
        else:
            raise ValueError(f"Unknown repository type: {repo_type}")
