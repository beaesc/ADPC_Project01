import os

def handle():
    print("\nConfiguration Properties:")
    print(f"Default Repository: {os.getenv('DEFAULT_REPO', 'not set')}")
    print(f"Installation Path: {os.getenv('INSTALL_PATH', './installed_packages/')}")
