import json
import os
from database.repository_factory import RepositoryFactory
from database.models import SessionLocal, Package

def handle():
    path = input("Enter path to directory: ")
    file_path = os.path.join(path, "publish.json")

    if not os.path.exists(file_path):
        print("Error: publish.json file not found.")
        return
    
    with open(file_path, "r") as file:
        try:
            data = json.load(file)
        except json.JSONDecodeError:
            print("Error: Invalid JSON format.")
            return

    required_fields = ["package_name", "description", "version", "author_id", "artifact_path"]
    
    if not all(field in data for field in required_fields):
        print("Error: Missing required fields in publish.json.")
        return

    repo = RepositoryFactory.get_repository("package")
    repo.publish_package(
        name=data["package_name"],
        description=data["description"],
        version=data["version"],
        author=data["author_id"],
        artifact_path=data["artifact_path"]
    )

    print(f"Package '{data['package_name']}' published successfully!")

    # Open ORM (Alembic) Session
    session = SessionLocal()

    try:
        # Create new package object using ORM
        new_package = Package(
            name=data["package_name"],
            description=data["description"],
            version=data["version"],
            author_id=None,  # This should reference an actual author in the DB
            artifact_path=data["artifact_path"]
        )

        # Add to database
        session.add(new_package)
        session.commit()
        session.refresh(new_package)

        print(f"Package '{data['package_name']}' published successfully!")
    
    except Exception as e:
        session.rollback()
        print(f"Error publishing package: {e}")
    
    finally:
        session.close()
