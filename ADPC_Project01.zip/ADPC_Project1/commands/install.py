import os
from database.repository_factory import RepositoryFactory

def handle():
    package_name = input("Enter package name: ")
    repo = RepositoryFactory.get_repository("package")

    package = repo.get_package_binary(package_name)
    if not package:
        print("Package not found.")
        return

    install_path = os.getenv("INSTALL_PATH", "./installed_packages/")
    os.makedirs(install_path, exist_ok=True)
    
    package_path = os.path.join(install_path, os.path.basename(package["artifact_path"]))
    
    with open(package_path, "wb") as file:
        file.write(package["binary"])

    print(f"Package '{package_name}' installed at {package_path}")
