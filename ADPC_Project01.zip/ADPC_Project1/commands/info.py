from database.repository_factory import RepositoryFactory

def handle():
    package_name = input("Enter package name: ")
    repo = RepositoryFactory.get_repository("package")

    package_info = repo.get_package_info(package_name)
    if not package_info:
        print("No package found.")
        return

    print("\nPackage Information:")
    print(f"Name: {package_info['name']}")
    print(f"Description: {package_info['description']}")
    print(f"Author: {package_info['author']}")
    print("Versions:")
    
    for version in package_info['versions']:
        print(f"- {version}")
