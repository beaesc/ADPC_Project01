from database.repository_factory import RepositoryFactory

def handle():
    repo_name = input("Enter repository name: ")
    repo = RepositoryFactory.get_repository("package")
    
    packages = repo.get_packages_by_repo(repo_name)
    if not packages:
        print("No packages found.")
        return
    
    print("Packages in repository:", repo_name)
    for pkg in packages:
        print(f"- {pkg.name} (Version: {pkg.version})")
