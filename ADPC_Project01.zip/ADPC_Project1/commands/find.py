from database.repository_factory import RepositoryFactory

def handle():
    search_query = input("Enter package name or keyword: ")
    repo = RepositoryFactory.get_repository("package")

    packages = repo.find_packages(search_query)
    if not packages:
        print("No matching packages found.")
        return

    print("Matching Packages:")
    for pkg in packages:
        print(f"- {pkg['name']} (Version: {pkg['version']})")
