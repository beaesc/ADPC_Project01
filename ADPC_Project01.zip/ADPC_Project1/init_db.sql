--psql "postgresql://postgres:BrNRtRfnOrm35ACw@nakedly-magnetic-coatimundi.data-1.use1.tembo.io:5432/postgres" -f init_db.sql
--SELECT table_name FROM information_schema.tables WHERE table_schema = 'public';



-- Drop existing tables to avoid conflicts
DROP TABLE IF EXISTS user_repository_access CASCADE;
DROP TABLE IF EXISTS users CASCADE;
DROP TABLE IF EXISTS dependencies CASCADE;
DROP TABLE IF EXISTS packages CASCADE;
DROP TABLE IF EXISTS authors CASCADE;
DROP TABLE IF EXISTS repositories CASCADE;

-- Create the authors table (One-to-Many relationship with packages - 1 author has many packages)
CREATE TABLE authors (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) UNIQUE
);

-- Create the repositories table (One-to-Many relationship with packages - 1 repo has many packages)
CREATE TABLE repositories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the packages table
CREATE TABLE packages (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    version VARCHAR(50) NOT NULL,
    description TEXT,
    author_id INT REFERENCES authors(id) ON DELETE SET NULL,
    repo_id INT REFERENCES repositories(id) ON DELETE CASCADE,
    artifact_path TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (name, version)
);

-- Create the package details table (One-to-One relationship)
CREATE TABLE package_details (
    package_id INT PRIMARY KEY REFERENCES packages(id),
    release_notes TEXT,
    documentation_link TEXT
);


-- Create a self-referencing dependencies table (Many-to-Many relationship within packages)
CREATE TABLE dependencies (
    package_id INT REFERENCES packages(id) ON DELETE CASCADE,
    dependency_id INT REFERENCES packages(id) ON DELETE CASCADE,
    PRIMARY KEY (package_id, dependency_id)
);

-- Create the users table
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) UNIQUE NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create a user repository access table (Many-to-Many relationship within users and repositories)
CREATE TABLE user_repository_access (
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    repo_id INT REFERENCES repositories(id) ON DELETE CASCADE,
    access_level VARCHAR(50) CHECK (access_level IN ('read', 'write', 'admin')),
    PRIMARY KEY (user_id, repo_id)
);
