import argparse
from commands import list, publish, info, install, find, config

def main():
    parser = argparse.ArgumentParser(description="Software Package Manager")
    subparsers = parser.add_subparsers(dest="command")

    # Define each subcommand
    subparsers.add_parser("list", help="Lists packages in a repository")
    subparsers.add_parser("publish", help="Publishes a package")
    subparsers.add_parser("info", help="Shows package information")
    subparsers.add_parser("install", help="Installs a package")
    subparsers.add_parser("find", help="Finds matching packages")
    subparsers.add_parser("config", help="Shows configuration properties")

    args = parser.parse_args()

    # Route the commands to appropriate handlers
    if args.command == "list":
        list.handle()
    elif args.command == "publish":
        publish.handle()
    elif args.command == "info":
        info.handle()
    elif args.command == "install":
        install.handle()
    elif args.command == "find":
        find.handle()
    elif args.command == "config":
        config.handle()
    else:
        parser.print_help()

if __name__ == "__main__":
    main()
