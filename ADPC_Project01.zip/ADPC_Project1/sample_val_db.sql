-- Insert test repositories
INSERT INTO repositories (name) VALUES ('default-repo');

-- Insert test authors
INSERT INTO authors (name, email) 
VALUES 
('John Doe', 'johndoe@example.com'),
('Jane Smith', 'janesmith@example.com');

-- Insert test packages
INSERT INTO packages (name, description, version, author_id, repo_id, artifact_path) 
VALUES 
('mypackage', 'A test package', '1.0.0', 1, 1, 's3://minio-bucket/mypackage-1.0.0.dll'),
('anotherpackage', 'Another package', '2.0.1', 2, 1, 's3://minio-bucket/anotherpackage-2.0.1.dll'),
('dependent-package', 'Depends on mypackage', '1.0.0', 1, 1, 's3://minio-bucket/dependent-package-1.0.0.dll');

-- Insert package details (One-to-One)
INSERT INTO package_details (package_id, release_notes, documentation_link) 
VALUES 
(1, 'Initial release with basic functionality.', 'https://docs.example.com/mypackage'),
(2, 'Bug fixes and performance improvements.', 'https://docs.example.com/anotherpackage'),
(3, 'Added dependency on mypackage.', 'https://docs.example.com/dependent-package');

-- Insert test dependencies (self-referencing many-to-many)
INSERT INTO dependencies (package_id, dependency_id) 
VALUES 
(3, 1);  -- dependent-package depends on mypackage

-- Insert test users
INSERT INTO users (username, email) 
VALUES 
('beaescribano', 'beae@example.com'),
('adminuser', 'admin@example.com');

-- Insert test user-repository access (many-to-many)
INSERT INTO user_repository_access (user_id, repo_id, access_level) 
VALUES 
(1, 1, 'admin'),
(2, 1, 'read');

-- Test unique constraint (this should fail if run twice)
-- INSERT INTO packages (name, version, description, author_id, repo_id, artifact_path) 
-- VALUES ('mypackage', '1.0.0', 'Duplicate package', 1, 1, 's3://minio-bucket/mypackage-1.0.0.dll');

-- Test foreign key constraint (this should fail if author_id 999 doesn't exist)
-- INSERT INTO packages (name, version, description, author_id, repo_id, artifact_path) 
-- VALUES ('orphan-package', '1.0.0', 'This should fail', 999, 1, 's3://minio-bucket/orphan-package.dll');

-- Test cyclic dependency (this should fail if cycle detection is enabled)
-- INSERT INTO dependencies (package_id, dependency_id) VALUES (1, 3);
